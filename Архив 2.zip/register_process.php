<?php
$servername = "localhost";
$username = "p-338798_admin";
$password = "p-338798_admin";
$dbname = "p-338798_admin";

// Connect to SQLite database
$conn = new SQLite3('database.db');

if (!$conn) {
    die("Connection failed: " . $conn->lastErrorMsg());
}

$tel = $conn->escapeString($_POST['tel']);
$passwordHash = password_hash($conn->escapeString($_POST['password']), PASSWORD_DEFAULT);
$institution_name = $conn->escapeString($_POST['institution']);
$first_name = $conn->escapeString($_POST['first_name']);
$last_name = $conn->escapeString($_POST['last_name']);

// Check if the user with the given phone number already exists
$check_user_sql = "SELECT * FROM users WHERE tel='$tel'";
$check_user_result = $conn->query($check_user_sql);

if ($check_user_result->fetchArray(SQLITE3_ASSOC)) {
    ?>
    <!DOCTYPE html>
    <!-- The rest of your HTML remains unchanged -->
    <?php
    header("refresh:2;url=register.php");
} else {
    // If the user does not exist, register a new user
    $get_institution_id_sql = "SELECT id, name FROM institutions WHERE name='$institution_name'";
    $get_institution_id_result = $conn->query($get_institution_id_sql);

    if ($row = $get_institution_id_result->fetchArray(SQLITE3_ASSOC)) {
        $institution_id = $row['id'];
        $institution_name = $row['name'];

        // Register a new user with a balance of 0.0
        $insert_user_sql = "INSERT INTO users (tel, password, institution, institution_name, first_name, last_name, balance) VALUES ('$tel', '$passwordHash', '$institution_id', '$institution_name', '$first_name', '$last_name', 0.0)";

        if ($conn->exec($insert_user_sql)) {
            // Generate random card information and add it to the database
            // The card-related code remains the same

            ?>
            <!DOCTYPE html>
            <!-- The rest of your HTML remains unchanged -->
            <?php
            header("refresh:2;url=login.php");
        } else {
            echo "Error: " . $conn->lastErrorMsg();
        }
    } else {
        echo "Error getting institution ID";
    }
}

$conn->close();
?>
